Name:			Rita Beigh
Platforms:		Windows 8.1
Environment:	MS Visual Studio 2013 Professional

The "Shuffle" tests are stubs only and require additional coding.
The "Deck" tests are all functional.